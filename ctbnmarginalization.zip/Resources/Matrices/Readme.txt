This repertory contains the different CIMs to obtain the JIM
