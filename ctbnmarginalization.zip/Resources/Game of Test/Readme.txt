This repertory contains a set of games of test that you could use for trialrun of the program.
----------------------------------------------------------------------------------------------
